package com.boa.kycprocess.configuration;



import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;

import com.mongodb.MongoClient;

@Configuration
public class DBConfiguration {

	@Value("${db_url}") // this enables to read the below params from props file
	private String url;
	@Value("${db_username}")
	private String username;
	@Value("${db_password}")
	private String password;
	@Value("${db_driver}")
	private String driverClassName;
	
	
	
	@Bean
	@ConditionalOnClass(DataSource.class)
	@Conditional(SQLConfiguration.class)
	public DataSource getInstance()
	{
		DataSourceBuilder dataSrcBuilder = DataSourceBuilder.create();
		dataSrcBuilder.url(url);
		dataSrcBuilder.driverClassName(driverClassName);
		dataSrcBuilder.password(password);
		dataSrcBuilder.username(username);
		return dataSrcBuilder.build();
		
	}
	
	
	
	 
	 
	 
	
}
